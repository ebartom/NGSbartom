The micro-RNA matrix files are based on the miRBase database, release 16.0 (Sep 2010)
(see http://microrna.sanger.ac.uk/sequences/).
Each matrix describes the 8-base seed of a micro-RNA.
For some of the popular species, or groups of species, we prepared matrix files
with only the relevant micro-RNAs, as detailed below.

human:
 Homo sapiens

mouse:
 Mus musculus

fruitfly:
 Drosophila melanogaster 

worms:
 Caenorhabditis briggsae
 Caenorhabditis elegans
 Caenorhabditis remanei
 Schmidtea mediterranea
